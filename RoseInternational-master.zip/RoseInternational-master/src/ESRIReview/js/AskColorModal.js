define([
	'dijit/_TemplatedMixin',
	'dijit/_WidgetBase',
	'dijit/_WidgetsInTemplateMixin',
	'dijit/Dialog',
	'dijit/form/Button',

	'dojo/dom-attr',

	'dojo/_base/declare',

	'dojo/text!./AskColorModal/templates/AskColorModal.html'

	// 'xstyle/css!./AskColorModal/css/AskColorModal.styl'
], function(
	_TemplatedMixin, _WidgetBase, _WidgetsInTemplateMixin, Dialog, Button,
	domAttr,
	declare,
	template
	// stylesheet
) {
	return declare([Dialog], {
		baseClass: 'AskColorModal',
		templateString: template,

		// Widget LifeCycle
		constructor: function() {
			console.log('AskColorModal constructor');
		},
		postMixInProperties: function() {
			this.inherited(arguments);
		},
		buildRendering: function() {
			this.inherited(arguments);
		},
		postCreate: function() {
			this.inherited(arguments);
		},
		startup: function() {
			this.inherited(arguments);
		},
		destroy: function() {
			this.inherited(arguments);
		},
		buttonClickEvent: function(evt) {
			var name = domAttr.get(evt.target, 'name');
			this.onCancel();
			if(this.chosenColorCallback) {
				this.chosenColorCallback(name);
			}
		}
	});
});