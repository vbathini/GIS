﻿Public Class MapMain
    Inherits System.Web.UI.Page


    Public Property MapURL As String
        Get
            Return ViewState("MapURL")
        End Get
        Set(value As String)
            ViewState("MapURL") = value
        End Set
    End Property

    Public Property jsonstring As String
        Get
            Return Session("jsonstring")
        End Get
        Set(value As String)
            Session("jsonstring") = value
        End Set
    End Property


    Public Property datatable As DataTable
        Get
            Return Session("datatable")
        End Get
        Set(value As DataTable)
            Session("datatable") = value
        End Set
    End Property

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        MapURL = "LeadMap.aspx"
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'MapURL = "LeadMap.aspx"
            lblMoreInfo.Text = "This data set provides the number and rate of testing for elevated blood lead levels in children age 72 months and under"
            lnkMoreInfo.Text = "EPHT Data Portal"
            'PopulateMapData()
            PopulateMapDataCoAtt()
        End If
    End Sub

    Private Sub PopulateMapData()
        Try
            Dim table1 = New DataTable("Acute Myocardial Infarction (AMI)")
            table1.Columns.Add("COUNTY")
            table1.Columns.Add("CROP")
            table1.Columns.Add("PAST")
            table1.Columns.Add("SOIL")
            table1.Columns.Add("WEED")

            table1.Rows.Add("Adair", "6.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Andrew", "7.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Atchison", "8.33", "22.12", "15.51", "10.85")
            table1.Rows.Add("Audrain", "9.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Barry", "1.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Barton", "1.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Bates", "3.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Benton", "4.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Bollinger", "5.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Boone", "6.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Buchanan", "7.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Butler", "8.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Caldwell", "9.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Callaway", "44.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Camden", "23.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Cape Girardeau", "16.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Carroll", "10.33", "30.12", "15.51", "10.85")
            table1.Rows.Add("Carter", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Cass", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Cedar", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Chariton", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Christian", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Clark", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Clay", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Clinton", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Cole", "210.33", "35.12", "415.51", "510.85")
            table1.Rows.Add("Cooper", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Crawford", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Dade", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Dallas", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Daviess", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("DeKalb", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Dent", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Douglas", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Dunklin", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Franklin", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Gasconade", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Gentry", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Greene", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Grundy", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Harrison", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Henry", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Hickory", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Holt", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Howard", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Howell", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Iron", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Jackson", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Jasper", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Jefferson", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Johnson", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Knox", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Laclede", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Lafayette", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Lawrence", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Lewis", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Lincoln", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Linn", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Livingston", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Macon", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Madison", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Maries", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Marion", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("McDonald", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Mercer", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Miller", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Mississippi", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Moniteau", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Monroe", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Montgomery", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Morgan", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("New Madrid", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Newton", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Nodaway", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Oregon", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Osage", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Ozark", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Pemiscot", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Perry", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Pettis", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Phelps", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Pike", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Platte", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Polk", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Pulaski", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Putnam", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Ralls", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Randolph", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Ray", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Reynolds", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Ripley", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Saline", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Schuyler", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Scotland", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Scott", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Shannon", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Shelby", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("St. Charles", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("St. Clair", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("St. Francois", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("St. Louis", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("St. Louis City", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Ste. Genevieve", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Stoddard", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Stone", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Sullivan", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Taney", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Texas", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Vernon", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Warren", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Washington", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Wayne", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Webster", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Worth", "10.33", "5.12", "15.51", "10.85")
            table1.Rows.Add("Wright", "10.33", "5.12", "15.51", "10.85")

            datatable = table1
            BindFooTable()
            'the dataset will be build in MapQueryBuilder and placed in a session
            jsonstring = helperUtils.ConvertToJSON(table1)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BindFooTable()
        Try

            gvData.DataSource = datatable
            gvData.DataBind()

            'Attribute to show the Plus Minus Button.
            gvData.HeaderRow.Cells(0).Attributes("data-class") = "expand"

            'gvData.HeaderRow.Cells(2).Attributes("data-hide") = "phone"
            'gvData.HeaderRow.Cells(4).Attributes("data-hide") = "phone"

            gvData.HeaderRow.TableSection = TableRowSection.TableHeader

            '//Adds THEAD and TBODY to GridView.
            'GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;

        Catch ex As Exception

        End Try
    End Sub


    Private Sub PopulateMapDataCoAtt()
        Try
            Dim table1 = New DataTable("Acute Myocardial Infarction (AMI)")
            '['OBJECTID', 'NAME', 'RATE', 'TESTOUTCOME', 'TEST_0_35', 'TEST_36_71', 'ELEVATED'];
            table1.Columns.Add("COUNTY")
            table1.Columns.Add("NAME")
            table1.Columns.Add("RATE")
            table1.Columns.Add("TESTOUTCOME")
            table1.Columns.Add("TEST_0_35")
            table1.Columns.Add("TEST_36_71")
            table1.Columns.Add("ELEVATED")

            table1.Rows.Add("Adair", "Adair", "133", "133", "133", "133", "133")
            table1.Rows.Add("Andrew", "Andrew", "178", "178", "178", "178", "178")
            table1.Rows.Add("Atchison", "Atchison", "213", "213", "213", "213", "213")
            table1.Rows.Add("Audrain", "Audrain", "70", "20", "198", "678", "1")
            table1.Rows.Add("Barry", "Barry", "270", "270", "270", "270", "270")
            table1.Rows.Add("Barton", "Barton", "70", "20", "198", "678", "1")
            table1.Rows.Add("Bates", "Bates", "70", "20", "198", "678", "1")
            table1.Rows.Add("Benton", "Benton", "70", "20", "198", "678", "1")
            table1.Rows.Add("Bollinger", "Bollinger", "70", "20", "198", "678", "1")
            table1.Rows.Add("Boone", "Boone", "70", "20", "198", "678", "1")
            table1.Rows.Add("Buchanan", "Buchanan", "70", "20", "198", "678", "1")
            table1.Rows.Add("Butler", "Butler", "70", "20", "198", "678", "1")
            table1.Rows.Add("Caldwell", "Caldwell", "70", "20", "198", "678", "1")
            table1.Rows.Add("Callaway", "Callaway", "70", "20", "198", "678", "1")
            table1.Rows.Add("Camden", "Camden", "70", "20", "198", "678", "1")
            table1.Rows.Add("Cape Girardeau", "Cape Girardeau", "70", "20", "198", "678", "1")
            table1.Rows.Add("Carroll", "Carroll", "70", "20", "198", "678", "1")
            table1.Rows.Add("Carter", "Carter", "70", "20", "198", "678", "1")
            table1.Rows.Add("Cass", "Cass", "70", "20", "198", "678", "1")
            table1.Rows.Add("Cedar", "Cedar", "70", "20", "198", "678", "1")
            table1.Rows.Add("Chariton", "Chariton", "70", "20", "198", "678", "1")
            table1.Rows.Add("Christian", "Christian", "70", "20", "198", "678", "1")
            table1.Rows.Add("Clark", "Clark", "70", "20", "198", "678", "1")
            table1.Rows.Add("Clay", "Clay", "70", "20", "198", "678", "1")
            table1.Rows.Add("Clinton", "Clinton", "70", "20", "198", "678", "1")
            table1.Rows.Add("Cole", "Cole", "7000", "2000", "10098", "67008", "1")
            table1.Rows.Add("Cooper", "Cooper", "70", "20", "198", "678", "1")
            table1.Rows.Add("Crawford", "Crawford", "70", "20", "198", "678", "1")
            table1.Rows.Add("Dade", "Dade", "70", "20", "198", "678", "1")
            table1.Rows.Add("Dallas", "Dallas", "70", "20", "198", "678", "1")
            table1.Rows.Add("Daviess", "Daviess", "70", "20", "198", "678", "1")
            table1.Rows.Add("DeKalb", "DeKalb", "70", "20", "198", "678", "1")
            table1.Rows.Add("Dent", "Dent", "70", "20", "198", "678", "1")
            table1.Rows.Add("Douglas", "Douglas", "70", "20", "198", "678", "1")
            table1.Rows.Add("Dunklin", "Dunklin", "70", "20", "198", "678", "1")
            table1.Rows.Add("Franklin", "Franklin", "70", "20", "198", "678", "1")
            table1.Rows.Add("Gasconade", "Gasconade", "70", "20", "198", "678", "1")
            table1.Rows.Add("Gentry", "Gentry", "70", "20", "198", "678", "1")
            table1.Rows.Add("Greene", "Greene", "70", "20", "198", "678", "1")
            table1.Rows.Add("Grundy", "Grundy", "70", "20", "198", "678", "1")
            table1.Rows.Add("Harrison", "Harrison", "70", "20", "198", "678", "1")
            table1.Rows.Add("Henry", "Henry", "70", "20", "198", "678", "1")
            table1.Rows.Add("Hickory", "Hickory", "70", "20", "198", "678", "1")
            table1.Rows.Add("Holt", "Holt", "70", "20", "198", "678", "1")
            table1.Rows.Add("Howard", "Howard", "70", "20", "198", "678", "1")
            table1.Rows.Add("Howell", "Howell", "70", "20", "198", "678", "1")
            table1.Rows.Add("Iron", "Iron", "70", "20", "198", "678", "1")
            table1.Rows.Add("Jackson", "Jackson", "70", "20", "198", "678", "1")
            table1.Rows.Add("Jasper", "Jasper", "70", "20", "198", "678", "1")
            table1.Rows.Add("Jefferson", "Jefferson", "70", "20", "198", "678", "1")
            table1.Rows.Add("Johnson", "Johnson", "70", "20", "198", "678", "1")
            table1.Rows.Add("Knox", "Knox", "70", "20", "198", "678", "1")
            table1.Rows.Add("Laclede", "Laclede", "70", "20", "198", "678", "1")
            table1.Rows.Add("Lafayette", "Lafayette", "70", "20", "198", "678", "1")
            table1.Rows.Add("Lawrence", "Lawrence", "70", "20", "198", "678", "1")
            table1.Rows.Add("Lewis", "Lewis", "70", "20", "198", "678", "1")
            table1.Rows.Add("Lincoln", "Lincoln", "70", "20", "198", "678", "1")
            table1.Rows.Add("Linn", "Linn", "70", "20", "198", "678", "1")
            table1.Rows.Add("Livingston", "Livingston", "70", "20", "198", "678", "1")
            table1.Rows.Add("Macon", "Macon", "70", "20", "198", "678", "1")
            table1.Rows.Add("Madison", "Madison", "70", "20", "198", "678", "1")
            table1.Rows.Add("Maries", "Maries", "70", "20", "198", "678", "1")
            table1.Rows.Add("Marion", "Marion", "70", "20", "198", "678", "1")
            table1.Rows.Add("McDonald", "McDonald", "70", "20", "198", "678", "1")
            table1.Rows.Add("Mercer", "Mercer", "70", "20", "198", "678", "1")
            table1.Rows.Add("Miller", "Miller", "70", "20", "198", "678", "1")
            table1.Rows.Add("Mississippi", "Mississippi", "70", "20", "198", "678", "1")
            table1.Rows.Add("Moniteau", "Moniteau", "70", "20", "198", "678", "1")
            table1.Rows.Add("Monroe", "Monroe", "70", "20", "198", "678", "1")
            table1.Rows.Add("Montgomery", "Montgomery", "70", "20", "198", "678", "1")
            table1.Rows.Add("Morgan", "Morgan", "70", "20", "198", "678", "1")
            table1.Rows.Add("New Madrid", "New Madrid", "70", "20", "198", "678", "1")
            table1.Rows.Add("Newton", "Newton", "70", "20", "198", "678", "1")
            table1.Rows.Add("Nodaway", "Nodaway", "70", "20", "198", "678", "1")
            table1.Rows.Add("Oregon", "Oregon", "70", "20", "198", "678", "1")
            table1.Rows.Add("Osage", "Osage", "70", "20", "198", "678", "1")
            table1.Rows.Add("Ozark", "Ozark", "70", "20", "198", "678", "1")
            table1.Rows.Add("Pemiscot", "Pemiscot", "70", "20", "198", "678", "1")
            table1.Rows.Add("Perry", "Perry", "70", "20", "198", "678", "1")
            table1.Rows.Add("Pettis", "Pettis", "70", "20", "198", "678", "1")
            table1.Rows.Add("Phelps", "Phelps", "70", "20", "198", "678", "1")
            table1.Rows.Add("Pike", "Pike", "70", "20", "198", "678", "1")
            table1.Rows.Add("Platte", "Platte", "70", "20", "198", "678", "1")
            table1.Rows.Add("Polk", "Polk", "70", "20", "198", "678", "1")
            table1.Rows.Add("Pulaski", "Pulaski", "70", "20", "198", "678", "1")
            table1.Rows.Add("Putnam", "Putnam", "70", "20", "198", "678", "1")
            table1.Rows.Add("Ralls", "Ralls", "70", "20", "198", "678", "1")
            table1.Rows.Add("Randolph", "Randolph", "70", "20", "198", "678", "1")
            table1.Rows.Add("Ray", "Ray", "70", "20", "198", "678", "1")
            table1.Rows.Add("Reynolds", "Reynolds", "70", "20", "198", "678", "1")
            table1.Rows.Add("Ripley", "Ripley", "70", "20", "198", "678", "1")
            table1.Rows.Add("Saline", "Saline", "70", "20", "198", "678", "1")
            table1.Rows.Add("Schuyler", "Schuyler", "70", "20", "198", "678", "1")
            table1.Rows.Add("Scotland", "Scotland", "70", "20", "198", "678", "1")
            table1.Rows.Add("Scott", "Scott", "70", "20", "198", "678", "1")
            table1.Rows.Add("Shannon", "Shannon", "70", "20", "198", "678", "1")
            table1.Rows.Add("Shelby", "Shelby", "70", "20", "198", "678", "1")
            table1.Rows.Add("St. Charles", "St. Charles", "70", "20", "198", "678", "1")
            table1.Rows.Add("St. Clair", "St. Clair", "70", "20", "198", "678", "1")
            table1.Rows.Add("St. Francois", "St. Francois", "70", "20", "198", "678", "1")
            table1.Rows.Add("St. Louis", "St. Louis", "70", "20", "198", "678", "1")
            table1.Rows.Add("St. Louis City", "St. Louis City", "70", "20", "198", "678", "1")
            table1.Rows.Add("Ste. Genevieve", "Ste. Genevieve", "70", "20", "198", "678", "1")
            table1.Rows.Add("Stoddard", "Stoddard", "70", "20", "198", "678", "1")
            table1.Rows.Add("Stone", "Stone", "70", "20", "198", "678", "1")
            table1.Rows.Add("Sullivan", "Sullivan", "70", "20", "198", "678", "1")
            table1.Rows.Add("Taney", "Taney", "70", "20", "198", "678", "1")
            table1.Rows.Add("Texas", "Texas", "70", "20", "198", "678", "1")
            table1.Rows.Add("Vernon", "Vernon", "70", "20", "198", "678", "1")
            table1.Rows.Add("Warren", "Warren", "70", "20", "198", "678", "1")
            table1.Rows.Add("Washington", "Washington", "70", "20", "198", "678", "1")
            table1.Rows.Add("Wayne", "Wayne", "70", "20", "198", "678", "1")
            table1.Rows.Add("Webster", "Webster", "70", "20", "198", "678", "1")
            table1.Rows.Add("Worth", "Worth", "70", "20", "198", "678", "1")
            table1.Rows.Add("Wright", "Wright", "70", "20", "198", "678", "1")

            datatable = table1
            BindFooTable()
            'the dataset will be build in MapQueryBuilder and placed in a session
            jsonstring = helperUtils.ConvertToJSON(table1)
        Catch ex As Exception

        End Try
    End Sub


End Class