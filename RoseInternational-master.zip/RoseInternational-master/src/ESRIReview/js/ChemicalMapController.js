var loading;
var fieldChoice = 1;
var fields = [];
var jsonValues;
var statsArray = [];
var statsValues = {};
var initDraw = true;
define([
	'dijit/registry',

	'dojo/_base/array',
	'dojo/data/ItemFileReadStore',
	'dojo/dom',
	'dojo/dom-construct',
	'dojo/json',
	'dojo/keys',
	'dojo/on',
	'dojo/parser',
	'dojo/_base/lang',

	'esri/Color',
	'esri/dijit/HomeButton',
	'esri/dijit/InfoWindow',
	'esri/dijit/Legend',
	'esri/dijit/Popup',
	'esri/domUtils',
	'esri/geometry/Extent',
	'esri/InfoTemplate',
	'esri/layers/FeatureLayer',
	'esri/layers/GraphicsLayer',
	'esri/layers/LabelLayer',
	'esri/map',
	'esri/renderers/ClassBreaksRenderer',
	'esri/renderers/SimpleRenderer',
	'esri/renderers/SimpleRenderer',
	'esri/request',
	'esri/SpatialReference',
	'esri/symbols/SimpleFillSymbol',
	'esri/symbols/SimpleLineSymbol',
	'esri/symbols/TextSymbol',
	'esri/urlUtils',
	'esri/renderers/UniqueValueRenderer',
	'esri/graphic',
	'esri/tasks/PrintTask',
	'esri/tasks/PrintTemplate',
	'esri/tasks/PrintParameters',
	'esri/dijit/BasemapGallery',

	'js/AskColorModal',

	'extras/colorbrewer',

	'dijit/form/HorizontalSlider',
	'dijit/form/Button',
	'dijit/DropDownMenu',
	'dijit/form/ComboBox',
	'dijit/form/ComboButton',
	'dijit/form/DropDownButton',
	'dijit/form/FilteringSelect',
	'dijit/layout/BorderContainer',
	'dijit/layout/ContentPane',
	'dijit/MenuItem',
	'dijit/TitlePane',
	'dijit/Toolbar',
	'dojo/domReady!'
], function(
	registry,
	arrayUtils, ItemFileReadStore, dom, domConstruct, JSON, keys, on, parser, lang,
	Color, HomeButton, InfoWindow, Legend, Popup, domUtils, Extent, InfoTemplate, FeatureLayer, GraphicsLayer, LabelLayer, Map, ClassBreaksRenderer, SimpleRenderer, SimpleRenderer, esriRequest, SpatialReference, SimpleFillSymbol, SimpleLineSymbol, TextSymbol, urlUtils, UniqueValueRenderer, Graphic, PrintTask, PrintTemplate, PrintParameters, BasemapGallery,
	AskColorModal,
	colorbrewer,
	HorizontalSlider, Button
) {

	return {
		initialOpacity: 0.8,

		startup: function(myjson) {
			parser.parse();

			// urls:
			this.pathName = 'https://ogitest.oa.mo.gov';
			this.featureLayerUrl = this.pathName + "/arcgis/rest/services/BaseMap/county_simple/MapServer/0";
			this.printTaskUrl = this.pathName + '/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task';

			loading = dom.byId("loadingImg");
			spatialReference = new SpatialReference({
				wkid: 102100
			});
			startExtent = new Extent(-10583000, 4287025, -9979000, 4980462, spatialReference);

			var highlightFillSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
				new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([255, 255, 0]), 3), new Color([255, 255, 0, 0.1]))
			var countyFillSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_NULL,
				new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([149, 149, 149]), 2));

			var popup = new Popup({
				fillSymbol: highlightFillSymbol
			}, domConstruct.create("div"));

			this.map = new Map("mapDiv", {
				infoWindow: popup,
				basemap: "gray",
				center: [-92.595, 38.4],
				zoom: 7
			});

			this.defaultSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
				new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([182, 182, 182]), 1), new Color([190, 190, 190, 0.7]));

			this.polyOutlineSymbol = new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, new Color([182, 182, 182]), 1);

			var infoTemplate = new InfoTemplate("Layer Information");
			infoTemplate.setContent(lang.hitch(this, 'generateInfoContent'));



			this.featureLayer = new FeatureLayer(this.featureLayerUrl, {
				maxAllowableOffset: startExtent.getWidth() / this.map.width,
				mode: FeatureLayer.MODE_SNAPSHOT,
				outFields: ["*"],
				visible: true,
				infoTemplate: infoTemplate
			});
			// sets default renderer so layer isn't drawn until the data has been loaded and is joined
			this.featureLayer.setRenderer(new SimpleRenderer(null));

			//wait for request to finish before rendering
			var updateEnd = this.featureLayer.on("update-end", lang.hitch(this, function() {
				updateEnd.remove();
				this.askColorModal = new AskColorModal({
					title: "Please choose a color",
					style: "width: 300px;",
					chosenColorCallback: lang.hitch(this, function(chosenColor) {
						console.log('chosenColor:', chosenColor);
						this.initializeDrawFeatureLayer(myjson, chosenColor);
					})
				});
				this.askColorModal.show();

				this.addLabelLayer(this.featureLayer);
				this.addShadedLayer(this.featureLayer);
				this.addFeatureLayerSlider(this.featureLayer);
				this.addPrintButton();
				this.addBasemapGallery();
			}));

			this.map.addLayer(this.featureLayer);

			//event listeners
			this.map.on('update-start', lang.hitch(this, 'showLoading'));
			this.map.on('update-end', lang.hitch(this, 'hideLoading'));
		},
		initializeDrawFeatureLayer: function(data, chosenColor) {
			jsonValues = (typeof data === "string") ? JSON.parse(data) : data;
			//    console.log("join values, number of graphics: ", featureLayer.graphics.length);
			statsValues = {}; //used for function rather than specifying breakfield, since field won't exist at start of script

			var fieldCheck = jsonValues[0];

			for (var key in fieldCheck) {
				fields.push(key);
			}
			this.drawFeatureLayer(jsonValues, chosenColor);
		},
		drawFeatureLayer: function(jsonValues, chosenColor) {
			statsArray.length = 0;

			arrayUtils.forEach(jsonValues, function(g) {
				if (g.COUNTY !== "COUNTY") {
					var firstAtt = fields[fieldChoice]; //assume county is the first field, with the first data field being in position 1
					var val = g[firstAtt];
					statsValues[g.COUNTY] = val;
				}
			});
			// 1 - adds the attributes from JSON to the graphics,
			//2 - creates an array from the first non-county attribute to be used to generate class breaks
			arrayUtils.forEach(this.featureLayer.graphics, lang.hitch(this, function(graphic) {
				var nm = graphic.attributes.COUNTYNAME;
				var recData;
				var recNm;
				recData = this.findCountyData(jsonValues, nm);
				for (var att in recData) {
					graphic.attributes[att] = recData[att];
					if (fields[fieldChoice] == att) {
						if (recData[att] > 0) { //don't use negative numbers to generate class breaks
							statsArray.push(recData[att]);
						}
					}
				}
			}));
			//calculates the breaks based on information in statsArray
			//NOTE: will need to change this later to allow different fields to be used
			statsArray.sort(lang.hitch(this, 'sortNumber'));
			var lowestValue = statsArray[0];
			var highestValue = statsArray[statsArray.length - 1];
			var bambu = Bambu()
				.id('colorRamp')
				.data(statsArray, true); // passing true forces a classification to run, creating a style string
			var style = bambu.jsonstyle(); //original style before you reclassify
			var new_style = bambu.colors(chosenColor).classes(5).classify();
			var jstyle = bambu.jsonstyle();
			// console.log(jstyle);
			var classBr = bambu.intervals();
			//  console.log(classBr);
			var br = new ClassBreaksRenderer(this.defaultSymbol, lang.hitch(this, 'findBreakValue'));
			var breakData = JSON.parse(jstyle);
			var inter, nextup, nextInt, col, color, sym;
			for (var j in breakData.breaks) {
				inter = breakData.breaks[j].interval;
				nextup = parseInt(j) + 1;
				nextInt = classBr[nextup];
				if (!nextInt) {
					nextInt = highestValue;
				}
				col = breakData.breaks[j].color;
				color = new Color(col);
				sym = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID, this.polyOutlineSymbol, color);

				console.log('addBreak:', inter, nextInt, sym);
				br.addBreak(inter, nextInt, sym);
				//br.addBreak(breaks[0], breaks[1], new sfs("solid", outline, new Color([255, 255, 178, 0.75])));
			}
			this.featureLayer.setRenderer(br);
			this.featureLayer.setOpacity(this.initialOpacity);
			this.featureLayer.redraw();
			//this will create a legend at right side
			//var legend = new Legend({
			//    map: map,
			//    layerInfos: [{ "layer": this.featureLayer, "title": "Value" }]
			//}, "legendDiv");
			//legend.startup();
			//initDraw = false;
			//populateDropBox();
		},
		findCountyData: function(jsonValues, nm) {
			for (var i = 0; i < jsonValues.length; i++) {
				recNm = jsonValues[i].COUNTY;

				if (nm == recNm) {
					//     console.log("find a match on " + recNm);
					return jsonValues[i];
				}
			}
		},
		populateDropBox: function() {
			var fieldNames, fieldStore;
			fieldNames = {
				identifier: "value",
				label: "name",
				items: []
			};
			arrayUtils.forEach(fields, function(field, idx) { // add some field names to the FS
				if (field !== 'COUNTY') {
					fieldNames.items.push({
						"name": field,
						"value": idx
					});
				}
			});
			fieldStore = new ItemFileReadStore({
				data: fieldNames
			});
			registry.byId("fieldNames").set("store", fieldStore);
			registry.byId("fieldNames").set("value", fields[1]); // set a value in the select box
			registry.byId("fieldNames").on("change", getData);
		},
		getData: function() {
			fieldChoice = registry.byId("fieldNames").value;
			this.drawFeatureLayer(jsonValues);
		},
		generateInfoContent: function(graphic) {
			var returnString = "<table>";
			arrayUtils.forEach(fields, function(attName) {
				if (attName !== 'OBJECTID') {
					returnString += "<tr><td><b>" + attName + "</b></td><td>" + graphic.attributes[attName] + "</td></tr>";
				}
			});
			returnString += '</table>';
			return returnString;
		},
		taskErrorHandler: function(err) {
			console.log("error in task is " + err.error);
		},

		//used to sort an array of numbers, otherwise it would be treated as alphabetical sorting
		sortNumber: function(a, b) {
			return a - b;
		},

		// function used by the class breaks renderer instead of specifying a field, since those are added on the fly
		findBreakValue: function(graphic) {
			var county = graphic.attributes.COUNTYNAME;
			//   console.log ("county = " + county + ", value = " + statsValue[county]);
			return statsValues[county];
		},
		drawFeatureError: function(e) {
			console.log("error getting  data: ", e);
		},

		//functions for managing the status icon
		showLoading: function() {
			domUtils.show(loading);
			this.map.disableMapNavigation();
			this.map.hideZoomSlider();
		},
		hideLoading: function(error) {
			domUtils.hide(loading);
			this.map.enableMapNavigation();
			this.map.showZoomSlider();
		},


		addLabelLayer: function(theFeatureLayer) {
			console.log('addLabelLayer');
			var labelColor = new Color("#666");
			var countiesLabel = new TextSymbol().setColor(labelColor);
			countiesLabel.font.setSize("12pt");
			countiesLabel.font.setFamily("arial");
			var countiesLabelRenderer = new SimpleRenderer(countiesLabel);
			labels = new LabelLayer({
				id: "labels"
			}); // global on purpose for demonstration
			labels.addFeatureLayer(theFeatureLayer, countiesLabelRenderer, "{COUNTYNAME}");
			// add the label layer to the map:
			this.map.addLayer(labels);
		},
		showLabels: function() {
			labels.show();
		},
		hideLabels: function() {
			labels.hide();
		},

		addShadedLayer: function(theFeatureLayer) {
			this.shadedGl = new GraphicsLayer({
				visible: true
			});
			arrayUtils.forEach(theFeatureLayer.graphics, function(graphic) {
				this.shadedGl.add(new Graphic(graphic.toJson())); // make a copy
			}, this);


			var none = new SimpleFillSymbol(SimpleFillSymbol.STYLE_NULL,
				new SimpleLineSymbol(SimpleLineSymbol.STYLE_DASHDOT,
					new Color([255, 0, 0, 0]), 2), new Color([255, 0, 0, 0])
			);
			var sfs = new SimpleFillSymbol(SimpleFillSymbol.STYLE_DIAGONAL_CROSS,
				new SimpleLineSymbol(SimpleLineSymbol.STYLE_DASHDOT,
					new Color([255, 0, 0]), 2), new Color([255, 0, 0, 0.25])
			);

			// we have to use a UniqueValueRenderer because the type of the "CROP" is a string
			// eventually you probably want this to be a JS "Number" then you could use a
			// classBreaksRenderer.
			var renderer = new UniqueValueRenderer(none, "CROP");
			renderer.addValue({
				value: "6.33",
				symbol: sfs,
				label: "Low Density",
				description: "Low Density",
			});
			this.shadedGl.setRenderer(renderer);
			this.map.addLayer(this.shadedGl);
		},
		addFeatureLayerSlider: function(featureLayer) {
			this.hSlider = new HorizontalSlider({
				minimum: 0,
				maximum: 1.0,
				value: this.initialOpacity,
				intermediateChanges: true,
				onChange: lang.hitch(this, function(value) {
					featureLayer.setOpacity(value);
				})
			}).placeAt("bottomLeftContainer", "first");
			this.hSlider.startup();
		},
		addPrintButton: function() {
			this.printButton = new Button({
				innerHTML: 'Print Map',
				onClick: lang.hitch(this, 'launchPrintTask')
			}).placeAt("bottomLeftContainer", "last");
		},
		launchPrintTask: function() {
			// create the print Task:
			var printTask = new PrintTask(this.printTaskUrl);

			// template. We will hard-code one, but this could be chosen from a dropdown on the front-end:
			// https://developers.arcgis.com/javascript/jsapi/printparameters-amd.html#template
			var template = new PrintTemplate();
			template.format = "PDF";
			template.layout = "Letter ANSI A Landscape";
			template.preserveScale = false;
			template.layoutOptions = {
				titleText: 'This is the title',
				authorText: 'This is the author',
				copyrightText: 'Copyright State of MO'
			};

			// add the template to the params that get sent to printTask.execute():
			var params = new PrintParameters(); // see https://developers.arcgis.com/javascript/jsapi/printparameters-amd.html
			params.template = template;
			params.map = this.map;

			printTask.execute(params).then(lang.hitch(this, function(res) {
				if (res && res.hasOwnProperty('url')) {
					window.open(res.url);
				}
			}));
		},
		addBasemapGallery: function() {
			console.log('addBasemapGallery');
			this.basemapGallery = new BasemapGallery({
				showArcGISBasemaps: true,
				map: this.map
			}, "basemapRightContainer");
			this.basemapGallery.startup();
		}
	};
});