/**
Bambu generates thematic carto.js strings

Currently under active development and is being used to style
vector tile json data in modestmaps via Carto.js & VECNIK.js.

MIT License - Copryright 2012
*/
function Bambu() {
  // defaults
  var colors = 'Reds',
    classification = 'quantile',
    classes = 5,
    data = [],
    jsonstyle = '',
   intervals = [],
   colArray = [],
    id = '#',
    default_fill = '';
    
  // returnable class
  var bambu = function(){};

  // regenerates the classification
  bambu.classify = function(){
    var vals = data.sort(function(a, b) {
      return a - b;
    });
    switch (classification){
        case 'quantile':
            var breaks = [];
            var interval;
            breaks.push(vals[0]);
              for (var i = 1; i <= classes; i++) {
                interval = Math.round(i * (vals.length - 1) / classes);
                breaks.push( vals[Math.round(i * (vals.length - 1) / classes)])
              }
            break;
        case 'equal_interval':
            var breaks = [],
              range = vals[vals.length - 1] - vals[0];
              for (var i=0; i < classes; i++) {
                breaks.push(Math.floor(vals[0] + i * range / classes))
              }
            breaks[classes] = vals[vals.length - 1];
            break;
      }
  
    var bins = [];
     intervals = breaks;
     colArray.length = 0;
      jsonstyle = '{"breaks": [';
        for (var b = 0; b < breaks.length-1; b++){
          var break_val = breaks[b];
         bins.push('{"interval":'+break_val+' , "color":"' + rgb2hex(colorbrewer[colors][classes][b]) + '" }');
       //   bins.push('{"interval":'+break_val+' , "color":"' + colorbrewer[colors][classes][b] + '" }');
        colArray.push(rgb2hex(colorbrewer[colors][classes][b]));
        } 
    jsonstyle = jsonstyle + bins.join() ;
    jsonstyle += "]}";
 //   console.log(jsonstyle);
    return jsonstyle;
  }

  bambu.id = function(x, gen){
    if (!arguments.length) return id;
    id = x;
    if (gen) bambu.classify();
    return bambu;
  };

  bambu.data = function(x, gen){
    if (!arguments.length) return data;
    data = x;
    if (gen) bambu.classify();
    return bambu;
  };


  bambu.colors = function(x, gen){
    if (!arguments.length) return colors;
    colors = x;
    if (gen) bambu.classify();
    return bambu;
  };

   bambu.classes = function(x, gen){
    if (!arguments.length) return classes;
    classes = Math.min(x,9);
    classes = Math.max(classes,3);
    if (gen) bambu.classify();
    return bambu;
  };

  bambu.classification = function(x, gen){
    if (!arguments.length) return classification;
    classification = x;
    if (gen) bambu.classify();
    return bambu;
  };

  bambu.jsonstyle = function(){
    return jsonstyle;
  };
  
 bambu.colArray = function () {
   return colArray;
 }
  bambu.intervals = function () {
    return intervals;
  };

  function rgb2hex(rgb){
    rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
    return (rgb && rgb.length === 4) ? "#" +
      ("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
      ("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
      ("0" + parseInt(rgb[3],10).toString(16)).slice(-2) : '';
  }
  return bambu;
}

if (typeof module !== 'undefined' && module.exports) {
  //_ = require('underscore');
  colorbrewer = require('colorbrewer.js');
  module.exports.Bambu = Bambu;
}