﻿Public Class leadMapCoAtt
    Inherits System.Web.UI.Page

    Public Property jsonstring As String
        Get
            Return Session("jsonstring")
        End Get
        Set(value As String)
            Session("jsonstring") = value
        End Set
    End Property


    Public Property datatable As DataTable
        Get
            Return Session("datatable")
        End Get
        Set(value As DataTable)
            Session("datatable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class