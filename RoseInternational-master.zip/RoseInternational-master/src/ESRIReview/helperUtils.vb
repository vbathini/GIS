﻿Public Class helperUtils

    ''' <summary>
    ''' This function will convert a datatable to JSON object
    ''' </summary>
    ''' <param name="aDT"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ConvertToJSON(ByRef aDT As DataTable) As String
        Dim jSONStr As String = ""

        Dim Jserializer As New System.Web.Script.Serialization.JavaScriptSerializer()
        Dim rowsList As New List(Of Dictionary(Of String, Object))()
        Dim row As Dictionary(Of String, Object)
        For Each dr As DataRow In aDT.Rows
            row = New Dictionary(Of String, Object)()
            For Each col As DataColumn In aDT.Columns
                row.Add(col.ColumnName, dr(col))
            Next
            rowsList.Add(row)
        Next
        jSONStr = Jserializer.Serialize(rowsList)

        Return jSONStr
    End Function
End Class
